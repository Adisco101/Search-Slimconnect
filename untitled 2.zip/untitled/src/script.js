// Get HTML elements
const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const searchResults = document.getElementById('search-results');
const countrySelect = document.getElementById('country-select');
const stateSelect = document.getElementById('state-select');
const skillSelect = document.getElementById('skill-select');

// Data array
const users = [
  { id: 1, name: 'John Doe', country: 'USA', state: 'California', skill: 'Web Development', contact: 'johndoe@example.com' },
  { id: 2, name: 'Jane Smith', country: 'Canada', state: 'Ontario', skill: 'Graphic Design', contact: 'janesmith@example.com' },
  { id: 3, name: 'Emeka Ngwu', country: 'Nigeria', state: 'Lagos', skill: 'Web Development', contact: 'emekangwu@example.com' },
  // Add more users here...
];

// Country-states mapping
const countryStates = {
  USA: ['California', 'New York', 'Texas'],
  Canada: ['Ontario', 'Quebec', 'British Columbia'],
  Nigeria: ['Lagos', 'Abuja', 'Kano', 'Rivers', 'Enugu'],
};

// Populate states for selected country
countrySelect.addEventListener('change', () => {
  const selectedCountry = countrySelect.value;
  stateSelect.disabled = false;
  
  if (selectedCountry === 'All') {
    stateSelect.innerHTML = '<option value="All">All States</option>';
    stateSelect.disabled = true;
  } else {
    const states = countryStates[selectedCountry];
    stateSelect.innerHTML = '';
    states.forEach((state) => {
      const option = document.createElement('option');
      option.value = state;
      option.text = state;
      stateSelect.appendChild(option);
    });
    stateSelect.appendChild(new Option('All', 'All'));
  }
});

// Add event listener to search button
searchButton.addEventListener('click', () => {
  const searchTerm = searchInput.value.trim().toLowerCase();
  const selectedCountry = countrySelect.value;
  const selectedState = stateSelect.value;
  const selectedSkill = skillSelect.value;

  // Filter logic
  const filteredResults = users.filter((user) => {
    return (
      (selectedCountry === 'All' || user.country === selectedCountry) &&
      (selectedState === 'All' || user.state === selectedState) &&
      (selectedSkill === 'All' || user.skill === selectedSkill) &&
      (user.name.toLowerCase().includes(searchTerm) || user.skill.toLowerCase().includes(searchTerm))
    );
  });

  displayResults(filteredResults);
});

// Display search results
function displayResults(results) {
  searchResults.innerHTML = '';
  results.forEach((result) => {
    const resultHTML = `
      <div>
        <h2>${result.name}</h2>
        <p>Country: ${result.country}</p>
        <p>State: ${result.state}</p>
        <p>Skill: ${result.skill}</p>
        <p>Contact: ${result.contact}</p>
      </div>
    `;
    searchResults.insertAdjacentHTML('beforeend', resultHTML);
  });
}
